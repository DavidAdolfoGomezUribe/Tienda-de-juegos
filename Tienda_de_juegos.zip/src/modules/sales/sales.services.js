import { getDB, connect } from "../../db/config.js";
import { ObjectId } from "mongodb";
import { error, log } from "console"

await connect()
const db = getDB()

export async function findAllSalesServices() {
    const products = await db.collection("sales").find().toArray()
    return products
}

export async function postOneSaleServices() {
    
}